# Eigong Prime

Mods Eigong to be harder, she will chain moves a lot more frequently and relentlessly. Also phase 1 can now use the talisman follow ups presente in phase 2 and 3 and phases 2 and 3 can chain Pokes just like phase 1